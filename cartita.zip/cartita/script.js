const sobre = document.getElementById("sobre");
const carta = document.getElementById("carta");
const cerrar = document.getElementById("cerrar");

const lluvia = document.querySelector(".lluvia-decoraciones");

// Abrir la carta
sobre.addEventListener("click", () => {
    carta.classList.remove("oculta");
    sobre.style.display = "none";
});

// Cerrar la carta
cerrar.addEventListener("click", () => {
    carta.classList.add("oculta");
    sobre.style.display = "block";
});

// Crear la lluvia de flores y corazones azules
function crearLluvia() {
    const simbolos = ["💙", "❀", "✿", "♡", "❁"];
    const cantidad = 30;

    for (let i = 0; i < cantidad; i++) {
        const decoracion = document.createElement("span");

        decoracion.classList.add("decoracion");

        decoracion.textContent =
            simbolos[Math.floor(Math.random() * simbolos.length)];

        decoracion.style.left = Math.random() * 100 + "%";

        decoracion.style.setProperty(
            "--tamano",
            14 + Math.random() * 16 + "px"
        );

        decoracion.style.setProperty(
            "--duracion",
            5 + Math.random() * 7 + "s"
        );

        decoracion.style.setProperty(
            "--retraso",
            -Math.random() * 12 + "s"
        );

        decoracion.style.setProperty(
            "--desplazamiento",
            Math.random() * 140 - 70 + "px"
        );

        lluvia.appendChild(decoracion);
    }
}

crearLluvia();